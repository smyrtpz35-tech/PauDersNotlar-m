/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.homework;
import java.util.Scanner;
/**
 *
 * @author Sümeyra Topuz 25253052 Bilgisayar Mühendisliği 1. sınıf ödev 
 */
public class Homework  {                                                        //Sınıfımın ismi: Homework
    public static void main(String[] args) {                                    //Ana Metodum
        
                                                                                //Kullanıcıdan istenildiği kadar öğrenci sayısı al.
            System.out.print("Ogrenci sayisini giriniz: ");                     //Kullanıcıya belirtme 
            Scanner scan = new Scanner(System.in);                              //Kullanıcıdan alma
        int number  = scan.nextInt();                                           //Alınan değeri bir değişkene atama
   
                                                                                //Kullanıcı birden fazla öğrenci girme olasılığı olduğu için dizi oluşturma ve atama.
                                                                                //Dizi boyutunu bellekte istenildiği kadar yer kaplamansı için girilen sayı kadar dizi boyutu oluşturma
        int[] studentId = new int[number];                                      //Öğrenci numarası dizisi
        String[] studentName = new String[number];                              //Öğrenci isimleri için dizi
        double[] midterm = new double[number];                                  //Öğrencinin vize notları için dizi
        double[] finalExam = new double[number];                                //Öğrencinin final notları için dizi
        int choice;
        double[] average = new double[number];                                  //ortalama için dizi olusturma
            
                                                                                //Kullanıcıdan öğrencilerin bilgilerini alma
                                                                                //for döngüsü ile her bir dizi boyutuna girilen bilgileri atama
        for(int i=0;i<number;i++){
            System.out.print((i+1)+".  Ogrenci numarasini giriniz: ");
            studentId[i] = scan.nextInt();                                      //Öğrenci no için
       
            System.out.print((i+1)+".  Ogrenci ismini giriniz: ");
            studentName[i]=scan.next();                                         //Öğrenci ismi için 
       
            System.out.print((i+1)+".  Ogrencinin nesneye yonelik programlama dersinin vize notunu giriniz: ");
            midterm[i]=scan.nextDouble();                                       //Vize notu
       
            System.out.print((i+1)+".  Ogrencinin nesneye yonelik programlama dersinin final notunu giriniz: ");
            finalExam[i]=scan.nextDouble();                                     //Final notu
       
     
            average[i]=(0.4*midterm[i])+(finalExam[i]*0.6);                     //ortalamayı hesaplayıp dizilere atama 

}
do{     
                                                                                //Derste switch case deginilmedigi icin if-else'li ve do-while kullanarak yapma geregi duydum
            System.out.println("\n--- MENU ---");
            System.out.println("1 - Giris sirasina gore bilgileri goruntule");
            System.out.println("2 - Sinav ortalamalarini hesapla");
            System.out.println("3 - 60'dan kucuk not alan ogrencileri goster");
            System.out.println("4 - Ortalama ustu ogrencileri goster");
            System.out.println("5 - 60'dan kucuk notlarin sayisini goster");
            System.out.println("6 - En yuksek sinav sonucunu goster");
            System.out.println("7 - En dusuk sinav sonucunu goster");
            System.out.println("8 - Kucukten buyuge siralama yap");
            System.out.println("0 - Cikis");
            System.out.print("\nYapmak istediginiz seciminizi yapiniz: ");
            choice = scan.nextInt();
            
        if(choice==1){
            EntryOrder(number,studentId,studentName,midterm,finalExam);         //Bilgileri metod çağırarak yazdırma
}   
        else if(choice==2){
            ExamResultAverage(number,midterm,finalExam,studentId,studentName,average);  //Sınav ortalamasını metod çagırarak gerçekleştirme     
}
        else if(choice==3){ 
            FailNote(number,average,studentId,studentName);                     //60'dan kucuk not alan kişileri yazdırmak method cagırma     
}
        else if(choice==4){
            PassedNoteAverage(number,average,studentId,studentName);            //Ortalama ustu not alan ogrencilerin isim ve numaralarını yazdırmak için method cagırma
}
        else if(choice==5){
            FailNoteCount(number,average);                                      //60'dan kucuk not alan kişilerin sayisi metod cagırma}
}
        else if(choice==6){
            HighestExamResult(number,average);                                  //Girilen notlar arasından en yüksek notu hesaplayan metodu çağırma
}
        else if(choice==7){
            LowestExamResult(number,average);                                   //Girilen notlar arasından en düşük notu hesaplayan metodu çağırma}
}
        else if(choice==8){
            DisplayExamResult(number,studentId,studentName,average);            //Sinav sonuclarina gore kucukten buyuge siralamayı yazan metodu çağırma
}
        else if(choice==0){
            System.out.println("Programdan cikiliyor");
}        
}   
while(choice!=0);
}
//Okunan bu bilgileri giriş sırasına göre görüntüleyen metodu 
    public static void EntryOrder(int number,int[] studentId,String[]studentName,double[]midterm,double[] finalExam){
//tablo şeklinde yazdırmaya çalıstım %10s şeklinde yazmayı gecen dönem gördüğümüz için yazma gereği duydum, 
 //%n kullanımını kesfettim ama \n ile aynı işlevi goruldugunu okuyunca \n koyma geregi duydum
        System.out.println(" ");
            System.out.printf("%-10s %-10s %-10s %-10s\n", "No", "Name", "Vize", "Final");
        for(int j=0;j<number;j++){
            System.out.printf("%-5d %-10s %-10.2f %-10.2f\n",studentId[j], studentName[j], midterm[j],finalExam[j]);
        }
}
      
//Sınav sonuç ortalamasını bulan metodu(vize %40, final %60) ve aynı zamanda 60'dan kucuk sınav sonuclarını yazdıran method( method içindedir) 
    public static void ExamResultAverage(int number,double[] midterm, double []finalExam,int[] studentId,String[]studentName,double[]average){   
        System.out.println(" ");
        for(int k=0;k<number;k++){
            
            System.out.println((k+1)+". "+"Sinav ortalamasi: "+(double)average[k]);     //dizileri yazdırma girilen ogrencilerin verilerin göre sırası ile yazdırma
        }
    }

 //60'dan küçük sınav sonuçlarını ve bu sonuçlara ait öğrenci numaralarını ve isimlerini görüntüleyen metodu,
    public static void FailNote(int number,double[] average,int[] studentId, String[]studentName){
           System.out.println("60'dan kucuk alan ogrencilerin numaralari ve isimleri\n");
        for(int a=0;a<number;a++){
            if(average[a]<60){              
              
                System.out.printf("No: %-10d Isim: %-10s\n",studentId[a], studentName[a]); 
            }
        }     
}
// Ortalamanın üstünde sınav sonuçlarını ve bu öğrencilere ait bilgileri görüntüleyen metod
    public static void PassedNoteAverage(int number,double[] average,int[] studentId, String[]studentName){
        System.out.println("Ortalama ustu ogrencilerin numaralari ve notları\n");
        double sum=0;
        double averageSum=0;
        for(int a=0;a<number;a++){
           sum+=average[a];
        }
        averageSum=sum/(average.length);
        for(int r=0;r<number;r++){
            if(average[r]>averageSum){
                System.out.printf("No: %-10d Not: %.2f\n", studentId[r],average[r]);
            }
        }
    }
    
    //60'dan kucuk not alan kişilerin sayisinı gösteren metod 
    public static void FailNoteCount(int number,double[]average){
        int FailNoteCount=0;
        for(int m=0;m<number;m++){    
            if(average[m]<60){
                FailNoteCount++;
            }
        }
                System.out.print("\n60'dan kucuk sinav sonuc degerlerinin sayisi: "+FailNoteCount);    
    }
    
    //Girilen notlar arasından en yüksek notu hesaplayan metodu
    public static void HighestExamResult(int number,double[]average){
        double HighestExamResult = average[0];
        for(int s=1;s<number;s++){
            if(average[s]>HighestExamResult){
            HighestExamResult=average[s];
            }
        }
        System.out.print("\nEn yuksek sinav sonucu: "+(double)HighestExamResult);
    }
    
    //Girilen notlar arasından en düşük notu hesaplayan metod
    public static void LowestExamResult(int number,double[]average){
        double LowestExamResult = average[0];
        for(int s=1;s<number;s++){
            if(average[s]<LowestExamResult){
            LowestExamResult=average[s];
            }
        }
        System.out.print("\nEn dusuk sinav sonucu: "+(double)LowestExamResult);
    }
    
    //Sinav sonuclarina gore kucukten buyuge siralamayı yazan metod
    public static void DisplayExamResult(int number,int[]studentId,String[]studentName,double[] average){
        double temporaryValue=0;
        int temporaryValue2=0;
        String name= null;
         
        for(int b=0;b<average.length-1;b++){
        for(int t=0;t<average.length-1-b;t++){
            if(average[t]>average[t+1]){
                //ortalama 
                temporaryValue = average[t+1];
                average[t+1]=average[t];
                average[t]=temporaryValue;
                //name
                name = studentName[t+1];
                studentName[t+1]=studentName[t];
                studentName[t]=name;
                //studentId
                temporaryValue2 = studentId[t+1];
               studentId[t+1]=studentId[t];
                studentId[t]=temporaryValue2;
            }
        }
        }       
        System.out.print("\nSinav sonuclarina gore kucukten buyuge siralama: \n\n");
        
        for(int n=0;n<number;n++){    
        System.out.println("No: "+studentId[n]+" \tIsim: "+studentName[n]+"\tNot: "+average[n]);
        }      
    }
 }

    
    
