/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package nyp;

public class NYP {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Animal anm1 = new Animal();
        anm1.eat();
        
        Dog d1 = new Dog();
        d1.eat();
        d1.havla();
        
        Puppy p1 = new Puppy();
        p1.eat();
        p1.havla();
        p1.weep();
        
        System.out.println("//////////////");
        
        Person prs = new Person("Ahmet", "İstanbul");
        
        Student student = new Student("Can", "Denizli", 
                "Bilgisayar Müh.", 4, 1000);
        
        
        Staff staff = new Staff("Veli", "Denizli", "Paü", 50000);
        
        System.out.println(prs);
        System.out.println(student);
        System.out.println(staff);
        
     
    }
    
}
