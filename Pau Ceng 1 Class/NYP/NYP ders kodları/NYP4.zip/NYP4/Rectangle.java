/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.nyp4;

/**
 *
 * @author behlulsarikaya
 */
public class Rectangle {
   
    private int uzunKenar;
    private int kisaKenar;
    
    
    public Rectangle(int kKenar, int uKenar) {
        //this.uzunKenar = uKenar;
        //uzunKenar = uKenar;
        
        //this.kisaKenar = kKenar;
        
        setKisaKenar(kKenar);
        setUzunKenar(uKenar);
        
    }
    
    
    // Obje oluştururken herhangi bir parametre yollanmadığında bu yapıcı meyhod çalışır.
    public Rectangle() {
        uzunKenar = 1;
        kisaKenar = 1;
    }
    
    public int getKisaKenar(){
        return this.kisaKenar;
        //return kisaKenar;
    }
    
    public void setKisaKenar(int kisaKenar){
        
        if (kisaKenar > 0) {
            this.kisaKenar = kisaKenar;
        } else {
            System.out.println("Kisa Kenar Pozitif bir değer olmalıdır...");
        }
        
    }
    
    public int getUzunKenar() {
        return uzunKenar;
    }
    
    public void setUzunKenar(int uzunKenar) {
        if (uzunKenar > 0) {
            this.uzunKenar = uzunKenar;
        } else {
            System.out.println("Uzun Kenar Pozitif bir değer olmalıdır...");
        }
    }
    
    public int cevre() {
        return (uzunKenar+ kisaKenar) * 2;
        // return (this.uzunKenar+ this.kisaKenar) * 2;
    }
    
    public int alan() {
        return uzunKenar * kisaKenar;
        //return this.uzunKenar * this.kisaKenar; //diğer bir kullanım
    }
    
    
    public void bilgiYazdir() {
        System.out.println("Dikdörtgenin kısa kenarı : " + getKisaKenar());
        System.out.println("Dikdörtgenin uzun kenarı : " + getUzunKenar());
        System.out.println("Dikdörtgenin alanı : " + alan());
        System.out.println("Dikdörtgenin çevresi : " + cevre());
        
        // diğer bir kullanım
        System.out.println("Dikdörtgenin kısa kenarı : " + this.getKisaKenar());
        System.out.println("Dikdörtgenin uzun kenarı : " + this.getUzunKenar());
        System.out.println("Dikdörtgenin alanı : " + this.alan());
        System.out.println("Dikdörtgenin çevresi : " + this.cevre());
    }
    
    
    
    
}
