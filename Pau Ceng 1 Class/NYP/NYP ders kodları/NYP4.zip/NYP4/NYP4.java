/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.nyp4;

/**
 *
 * @author behlulsarikaya
 */
public class NYP4 {

    public static void main(String[] args) {
        
        
        Rectangle d1 = new Rectangle();
        
        //instance variable'lar public olarak ayarlansaydı....
//        d1.kisaKenar = 10;
//        System.out.println(d1.kisaKenar);
        
        d1.setKisaKenar(5);
        System.out.println(d1.getKisaKenar());
        
        
        Rectangle d2 = new Rectangle(-4, 5);
       
        System.out.println(d2.getKisaKenar());
        System.out.println(d2.cevre());
        System.out.println(d2.alan());


        d2.bilgiYazdir();
    
    }
}
