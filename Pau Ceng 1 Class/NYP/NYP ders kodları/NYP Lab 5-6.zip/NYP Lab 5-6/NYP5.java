


public class NYP5 {

    public static void main(String[] args) {
        

//           BankAccount hesap1 = new BankAccount("Ali Yılmaz", "12345678-TRY", 10000, "TRY");
//
//           hesap1.paraCek(500);
//           hesap1.paraCek(-100);
//           hesap1.paraYatir(-200);
//           hesap1.paraYatir(800);
//           
//           System.out.println(hesap1.getBakiye());
//           
//           hesap1.bilgiYazdir();
           
           
            Nabiz n1 = new Nabiz("Ali", "Yılmaz", 1950);
            
            System.out.println(n1.yasHesapla());
            System.out.println(n1.maxNabiz());
            
            
            System.out.println(n1);
           

    }
}
