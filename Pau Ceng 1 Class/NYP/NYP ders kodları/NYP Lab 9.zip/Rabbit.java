/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.nyp9;

public class Rabbit extends Animal{
   
    
   public Rabbit(int id) {
        setName("T"+id);
    }
    
    public void move() {
        //Math.random()  [0.0, 0.99999]
        //Math.random() * 10  [0.0, 9.99999]
        //Math.random() * 10 + 1 [1.0, 10.99999]
        // (int) (Math.random() * 10 + 1) [1, 10]
        
       int rnd = this.getRandomNumber();
       
       if (rnd >= 1 && rnd <= 2) {
           setPosition(0);
       } else if (rnd >= 3 && rnd <= 4) {
           setPosition(9);
       } else if (rnd == 5) {
           setPosition(-12);
       } else if (rnd >= 6 && rnd <= 8) {
           setPosition(1);
       } else {
           setPosition(-2);
       }
        
    }
    
    
}

