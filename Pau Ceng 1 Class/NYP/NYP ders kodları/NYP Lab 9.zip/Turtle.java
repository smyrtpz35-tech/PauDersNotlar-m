/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.nyp9;


public class Turtle extends Animal {
    
    public Turtle(int id) {
        setName("K"+id);
    }
    
    public void move() {
        //Math.random()  [0.0, 0.99999]
        //Math.random() * 10  [0.0, 9.99999]
        //Math.random() * 10 + 1 [1.0, 10.99999]
        // (int) (Math.random() * 10 + 1) [1, 10]
        
       int rnd = this.getRandomNumber();
       
       if (rnd >= 1 && rnd <= 5) {
           setPosition(3);
       } else if (rnd >= 6 && rnd <= 7) {
           setPosition(-6);
       } else {
           setPosition(1);
       }
        
    }
}
