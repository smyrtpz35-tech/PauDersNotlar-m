/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.nyp9;

import java.util.ArrayList;

public class NYP9 {

    public static void main(String[] args) {
        
        ArrayList<Animal> animals = new ArrayList<>();
        ArrayList<Animal> winnerAnimals = new ArrayList<>();
        
        int turtleCount = 5;
        int rabbitCount = 5;
        
        for (int i = 0; i<turtleCount; i++) {
            animals.add(new Turtle(i+1));
        }
        
        for (int i = 0; i<rabbitCount; i++) {
            animals.add(new Rabbit(i+1));
        }
        
        boolean isFinish = false;
        
        while (!isFinish) {
            
            display(animals);
            
            for (Animal anml : animals) {
                anml.move();
                
                if (anml.getPosition() == 70) {
                    isFinish = true;
                    winnerAnimals.add(anml);
                }
            }
            
        }
        
        display(animals);
        
        System.out.println("Yarışı Kazananlar : ");
        for (Animal anml : winnerAnimals) {
            System.out.println(anml.getName() + " ");
        }
        
    

    }
    
    
    public static void display(ArrayList animals) {
        
        for (Object anml : animals) { // upcasting
            Animal animal = (Animal) anml; // downcasting
            
            for(int i = 1; i <= 70; i++) {
                if (i == animal.getPosition()) {
                    System.out.print(animal.getName());
                } else {
                    System.out.print("-");
                }
            }
            
            System.out.println("");
        }
        
        System.out.println("/////////////////////////////////////////////////");
        
        
        
        
        
        
    }
    
    
    
}
