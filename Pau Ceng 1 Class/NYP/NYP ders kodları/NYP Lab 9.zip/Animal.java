/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.nyp9;


public abstract class Animal {
  
    private String name;
    private int position = 1;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getPosition() {
        return position;
    }

    public void setPosition(int moveAmount) {
        this.position += moveAmount;
        
        if (position < 1) position = 1;
        if (position > 70) position = 70;
    }
    
    public int getRandomNumber() {
        
        //Math.random()  [0.0, 0.99999]
        //Math.random() * 10  [0.0, 9.99999]
        //Math.random() * 10 + 1 [1.0, 10.99999]
        // (int) (Math.random() * 10 + 1) [1, 10]
        
        return (int) (Math.random() * 10 + 1);
    }
    
    abstract void move();
    
}
