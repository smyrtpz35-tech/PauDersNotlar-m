
public class FallHomeworkDeneme3 {
	
	public static Stack SıralıSıralama(Stack s1, Stack s2)throws Exception {
		Stack s3 = new Stack(s1.size()+s2.size()); //s3stack
		Stack s1temp = new Stack(s1.size());	//s1 Stack kopya 
		Stack s2temp = new Stack(s2.size());	//s2 Stack kopya 
		while(!s1.isEmpty()) {
			int val=s1.pop();
			s3.push(val); // s3tempe hepsini atıyorum 
			s1temp.push(val); // s1 ve s2 kopyalarım s1temp ve s2tempde duruyor
		}
		while(!s2.isEmpty()) {
			int val=s2.pop();
			s3.push(val);  // s3tempe hepsini atıyorum 
			s2temp.push(val);  // s1 ve s2 kopyalarım s1temp ve s2tempde duruyor
		}
		
		//s1 ve s2 stackleri koru
		
		while(!s1temp.isEmpty()) {			
			s1.push(s1temp.pop());
		}
		while(!s2temp.isEmpty()) {
			s2.push(s2temp.pop());
		}
		
		//s3temp de her iki stack imi boşalttım.		
		maxBularaksirala(s3);	
		return s3 ;
	}
	
	public static void maxBularaksirala(Stack s3)throws Exception {
		Stack s3temp = new Stack(s3.size());
		Stack maxtemp= new Stack(s3.size());
		
		while(!s3.isEmpty()) {
			int max = s3.pop();
				while(!s3.isEmpty()) {
					int val=s3.pop();
						if(max<val) {
							maxtemp.push(max);
							max=val;
						}
						else maxtemp.push(val);
				
						}
			
		while(!maxtemp.isEmpty()) {
			s3.push(maxtemp.pop());
				
			}

			s3temp.push(max);
			}
		
		while(!s3temp.isEmpty()) {
			int val=s3temp.pop();
			s3.push(val);  // s3temp'tekileri s3'e geri atıyorum
		}	
	} 	
	public static void main(String[] args) throws Exception {
		 Stack s1 = new Stack(5);
		 Stack s2= new Stack(7);
		 Stack s3;
		 
		 s1.push(9);
		 s1.push(7);
		 s1.push(10);
		 s1.push(23);
		 s1.push(12);
		 s2.push(5);
		 s2.push(1);
		 s2.push(1);
		 s2.push(3);
		 s2.push(8);
		 s2.push(16);
		 s2.push(17);
		 s1.display();
		 s2.display();
		 
		 s3=SıralıSıralama(s1,s2);
		
		 s3.display();
		 s1.display();
		 s2.display();
	 }
}
