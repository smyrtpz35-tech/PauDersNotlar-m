// fig06_03.c
// s dizisinin elemanlarını 2'den 10'a kadar olan çift sayılarla başlatma.
#include <stdio.h>
#define BOYUT 5 // dizinin maksimum boyutu

// main fonksiyonu programın çalışmasını başlatır
int main(void) {
   // sembolik sabit BOYUT dizi boyutunu belirtmek için kullanılabilir
   int dizi[BOYUT] = {0}; // dizi, BOYUT kadar elemana sahiptir

   for (size_t indeks = 0; indeks < BOYUT; ++indeks) { // değerleri ayarla
      dizi[indeks] = 2 + 2 * indeks;
   }

   printf("%s%8s\n", "Eleman", "Değer");

   // dizinin içeriğini tablo formatında yazdır
   for (size_t indeks = 0; indeks < BOYUT; ++indeks) {
      printf("%7zu%8d\n", indeks, dizi[indeks]);
   }
}
