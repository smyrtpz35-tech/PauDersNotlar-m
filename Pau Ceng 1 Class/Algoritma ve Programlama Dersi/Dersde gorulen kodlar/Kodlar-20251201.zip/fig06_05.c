// fig06_05.c
// Bir öğrenci anketini analiz etme.
#include <stdio.h>
#define CEVAP_BOYUTU 20 // dizi boyutlarını tanımla
#define FREKANS_BOYUTU 6

// main fonksiyonu programın çalışmasını başlatır
int main(void) {
   // anket cevaplarını cevaplar dizisine yerleştir
   int cevaplar[CEVAP_BOYUTU] =
      {1, 2, 5, 4, 3, 5, 2, 1, 3, 1, 4, 3, 3, 3, 2, 3, 3, 2, 2, 5};

   // frekans sayaçlarını 0 ile başlat
   int frekans[FREKANS_BOYUTU] = {0};

   // her cevap için cevaplar dizisinin bir elemanının
   // değerini seç ve bu değeri frekans dizisinde bir
   // indis olarak kullanarak elemanı artır
   for (size_t answer = 0; answer < CEVAP_BOYUTU; ++answer) {
      ++frekans[cevaplar[answer]];
   }

   // sonuçları göster
   printf("%s%12s\n", "Puan", "Frekans");

   // frekansları tablo formatında yazdır
   for (size_t rating = 1; rating < FREKANS_BOYUTU; ++rating) {
      printf("%6zu%12d\n", rating, frekans[rating]);
   }
}
