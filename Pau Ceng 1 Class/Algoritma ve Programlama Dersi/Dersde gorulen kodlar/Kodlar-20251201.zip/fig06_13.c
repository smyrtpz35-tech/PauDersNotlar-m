// fig06_13.c
// Dizi ile anket verisi analizi:
// Verilerin ortalama, medyan ve modunu hesaplama.
#include <stdio.h>
#define BOYUT 99

// fonksiyon prototipleri
void ortalama(const int cevap[]);
void medyan(int cevap[]);
void mod(int frekans[], const int cevap[]);
void bubbleSort(int a[]);
void diziYazdir(const int a[]);

// main fonksiyonu programın çalışmasını başlatır
int main(void) {
   int frekans[10] = {0}; // frekans dizisini başlat

   // cevap dizisini başlat
   int cevap[BOYUT] =
      {6, 7, 8, 9, 8, 7, 8, 9, 8, 9,
       7, 8, 9, 5, 9, 8, 7, 8, 7, 8,
       6, 7, 8, 9, 3, 9, 8, 7, 8, 7,
       7, 8, 9, 8, 9, 8, 9, 7, 8, 9,
       6, 7, 8, 7, 8, 7, 9, 8, 9, 2,
       7, 8, 9, 8, 9, 8, 9, 7, 5, 3,
       5, 6, 7, 2, 5, 3, 9, 4, 6, 4,
       7, 8, 9, 6, 8, 7, 8, 9, 7, 8,
       7, 4, 4, 2, 5, 3, 8, 7, 5, 6,
       4, 5, 6, 1, 6, 5, 7, 8, 7};

   // cevapları işle
   ortalama(cevap);
   medyan(cevap);
   mod(frekans, cevap);
}

// tüm cevap değerlerinin ortalamasını hesapla
void ortalama(const int cevap[]) {
   printf("%s\n%s\n%s\n", "-----------", "  Ortalama", "-----------");

   int toplam = 0; // dizinin elemanlarının toplamını tutan değişken

   // cevapların toplamını hesapla
   for (size_t j = 0; j < BOYUT; ++j) {
      toplam += cevap[j];
   }

   printf("Ortalama, veri elemanlarının toplamının\n"
          "veri elemanlarının sayısına (%u) bölünmesiyle elde edilir.\n"
          "Bu çalışmada ortalama değer: %u / %u = %.4f\n\n",
          BOYUT, toplam, BOYUT, (double) toplam / BOYUT);
}

// diziyi sırala ve medyan elemanının değerini belirle
void medyan(int cevap[]) {
   printf("\n%s\n%s\n%s\n%s", "--------", " Medyan", "--------",
          "Cevapların sıralanmamış dizisi");

   diziYazdir(cevap); // sıralanmamış diziyi yazdır

   bubbleSort(cevap); // diziyi sırala

   printf("%s", "\n\nSıralanmış dizi");
   diziYazdir(cevap); // sıralanmış diziyi yazdır

   // medyan elemanını göster
   printf("\n\nMedyan, sıralı %u elemanlı dizinin %u. elemanıdır.\n"
          "Bu çalışmada medyan: %u\n\n",
          BOYUT, BOYUT / 2, cevap[BOYUT / 2]);
}

// en sık tekrarlanan cevabı belirle
void mod(int frekans[], const int cevap[]) {
   printf("\n%s\n%s\n%s\n", "--------", "  Mod", "--------");

   // frekansları 0 olarak başlat
   for (size_t puan = 1; puan <= 9; ++puan) {
      frekans[puan] = 0;
   }

   // frekansları özetle
   for (size_t j = 0; j < BOYUT; ++j) {
      ++frekans[cevap[j]];
   }

   // sonuç sütunları için başlıkları yazdır
   printf("%s%11s%19s\n\n%54s\n%54s\n\n",
          "Cevap", "Frekans", "Bar Grafik",
          "1    1    2    2", "5    0    5    0    5");

   // sonuçları yazdır
   int enBuyuk = 0; // en büyük frekansı temsil eder
   int modDegeri = 0; // en sık tekrarlanan cevabı temsil eder

   for (size_t puan = 1; puan <= 9; ++puan) {
      printf("%8zu%11d          ", puan, frekans[puan]);

      // mod değeri ve en büyük frekans değerini takip et
      if (frekans[puan] > enBuyuk) {
         enBuyuk = frekans[puan];
         modDegeri = puan;
      }

      // frekans değerini temsil eden barı yazdır
      for (int h = 1; h <= frekans[puan]; ++h) {
         printf("%s", "*");
      }

      puts(""); // yeni bir satır başlat
   }

   // mod değerini göster
   printf("\nMod, en sık tekrarlanan değeri ifade eder.\n"
          "Bu çalışmada mod değeri: %d, bu %d kez tekrar etti.\n",
          modDegeri, enBuyuk);
}

// bubble sort algoritması ile diziyi sıraya sokma
void bubbleSort(int a[]) {
   // geçiş sayısını kontrol eden döngü
   for (int geis = 1; geis < BOYUT; ++geis) {
      // her geçişteki karşılaştırmaları kontrol eden döngü
      for (size_t j = 0; j < BOYUT - 1; ++j) {
         // elemanları sıralı değilse yer değiştir
         if (a[j] > a[j + 1]) {
            int tutucu = a[j];
            a[j] = a[j + 1];
            a[j + 1] = tutucu;
         }
      }
   }
}

// dizinin içeriğini yazdır (her satırda 20 değer)
void diziYazdir(const int a[]) {
   // dizi içeriğini yazdır
   for (size_t j = 0; j < BOYUT; ++j) {

      if (j % 20 == 0) { // her 20 değerde yeni satır başlat
         puts("");
      }

      printf("%2d", a[j]);
   }
}
