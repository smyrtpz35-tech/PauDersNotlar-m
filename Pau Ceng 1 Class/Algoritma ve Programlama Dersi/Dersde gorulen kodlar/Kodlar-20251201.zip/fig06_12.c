// fig06_12.c
// Bir dizinin elemanlarını artan sıraya göre sıralama.
#include <stdio.h>
#define BOYUT 10

// main fonksiyonu programın çalışmasını başlatır
int main(void) {
   int a[BOYUT] = {2, 6, 4, 8, 10, 12, 89, 68, 45, 37};

   puts("Veri elemanları orijinal sırada");

   // orijinal diziyi yazdır
   for (size_t i = 0; i < BOYUT; ++i) {
      printf("%4d", a[i]);
   }

   // kabarcık sıralama (bubble sort)
   // geçiş sayısını kontrol eden döngü
   for (int geis = 1; geis < BOYUT; ++geis) {
      // her geçişteki karşılaştırmaları kontrol eden döngü
      for (size_t i = 0; i < BOYUT - 1; ++i) {
         // ardışık elemanları karşılaştır ve ilk eleman
         // ikinci elemandan büyükse yer değiştir
         if (a[i] > a[i + 1]) {
            int gecici = a[i];
            a[i] = a[i + 1];
            a[i + 1] = gecici;
         }
      }
   }

   puts("\nVeri elemanları artan sırada");

   // sıralanmış diziyi yazdır
   for (size_t i = 0; i < BOYUT; ++i) {
      printf("%4d", a[i]);
   }

   puts("");
}
