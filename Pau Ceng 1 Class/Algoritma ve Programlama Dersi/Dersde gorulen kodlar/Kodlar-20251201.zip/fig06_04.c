// fig06_04.c
// Bir dizinin elemanlarının toplamını hesaplama.
#include <stdio.h>
#define BOYUT 5

// main fonksiyonu programın çalışmasını başlatır
int main(void) {
   // bir başlatıcı liste kullanarak diziyi başlat
   int dizi[BOYUT] = {1, 2, 3, 4, 5};
   int toplam = 0; // dizinin toplamı

   // dizi elemanlarının toplamını hesapla
   for (size_t i = 0; i < BOYUT; ++i) {
      toplam += dizi[i];
   }

   printf("Dizinin toplam değeri: %d\n", toplam);
}
