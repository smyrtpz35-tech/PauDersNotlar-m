// fig06_16.c
// Çok boyutlu dizilerin başlatılması.
#include <stdio.h>

void diziyiYazdir(int a[][3]); // fonksiyon prototipi

// main fonksiyonu programın çalışmasını başlatır
int main(void) {
   int dizi1[2][3] = {{1, 2, 3}, {4, 5, 6}};
   puts("dizi1'deki değerler satırlara göre:");
   diziyiYazdir(dizi1);

   int dizi2[2][3] = {{1, 2, 3}, {4, 5}};
   puts("dizi2'deki değerler satırlara göre:");
   diziyiYazdir(dizi2);

   int dizi3[2][3] = {{1, 2}, {4}};
   puts("dizi3'teki değerler satırlara göre:");
   diziyiYazdir(dizi3);
}

// iki satır ve üç sütun içeren diziyi yazdıran fonksiyon
void diziyiYazdir(int a[][3]) {
   // satırlar üzerinden döngü
   for (size_t i = 0; i <= 1; ++i) {
      // sütun değerlerini yazdır
      for (size_t j = 0; j <= 2; ++j) {
         printf("%d ", a[i][j]);
      }
      printf("\n"); // yeni bir satır başlat
   }
}
