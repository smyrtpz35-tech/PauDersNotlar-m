// fig06_09.c
// Statik diziler açıkça başlatılmadığında sıfır ile başlatılır.
#include <stdio.h>

void statikDiziBaslat(void); // fonksiyon prototipi
void otomatikDiziBaslat(void); // fonksiyon prototipi

// main fonksiyonu programın çalışmasını başlatır
int main(void) {
   puts("Her bir fonksiyona ilk çağrı:");
   statikDiziBaslat();
   otomatikDiziBaslat();

   puts("\n\nHer bir fonksiyona ikinci çağrı:");
   statikDiziBaslat();
   otomatikDiziBaslat();
   puts("");
}

// statik yerel bir dizi göstermek için fonksiyon
void statikDiziBaslat(void) {
   // fonksiyon çağrılmadan önce elemanlar sıfır ile başlatılır
   static int dizi1[3];

   puts("\nstatikDiziBaslat'a girerken değerler:");

   // dizi1'in içeriğini yazdır
   for (size_t i = 0; i <= 2; ++i) {
      printf("dizi1[%zu] = %d  ", i, dizi1[i]);
   }

   puts("\nstatikDiziBaslat'tan çıkarken değerler:");

   // dizi1'in içeriğini değiştir ve yazdır
   for (size_t i = 0; i <= 2; ++i) {
      printf("dizi1[%zu] = %d  ", i, dizi1[i] += 5);
   }
}

// otomatik yerel bir dizi göstermek için fonksiyon
void otomatikDiziBaslat(void) {
   // fonksiyon her çağrıldığında elemanlar başlatılır
   int dizi2[3] = {1, 2, 3};

   puts("\n\notomatikDiziBaslat'a girerken değerler:");

   // dizi2'nin içeriğini yazdır
   for (size_t i = 0; i <= 2; ++i) {
      printf("dizi2[%zu] = %d  ", i, dizi2[i]);
   }

   puts("\notomatikDiziBaslat'tan çıkarken değerler:");

   // dizi2'nin içeriğini değiştir ve yazdır
   for (size_t i = 0; i <= 2; ++i) {
      printf("dizi2[%zu] = %d  ", i, dizi2[i] += 5);
   }
}
