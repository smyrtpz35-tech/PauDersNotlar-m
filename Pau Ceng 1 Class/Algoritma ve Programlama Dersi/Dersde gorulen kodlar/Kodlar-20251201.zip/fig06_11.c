// fig06_11.c
// Dizileri ve dizinin bireysel elemanlarını fonksiyonlara geçirme.
#include <stdio.h>
#define BOYUT 5

// fonksiyon prototipleri
void diziDegistir(int b[], size_t boyut);
void elemanDegistir(int e);

// main fonksiyonu programın çalışmasını başlatır
int main(void) {
   int a[BOYUT] = {0, 1, 2, 3, 4}; // dizi a'yı başlat

   puts("Tüm diziyi referansla geçmenin etkileri:\n\n"
        "Orijinal dizinin değerleri:");

   // orijinal diziyi yazdır
   for (size_t i = 0; i < BOYUT; ++i) {
      printf("%3d", a[i]);
   }

   puts(""); // yeni satır yazdır

   diziDegistir(a, BOYUT); // dizi a'yı referansla diziDegistir fonksiyonuna geç
   puts("Değiştirilen dizinin değerleri:");

   // değiştirilmiş diziyi yazdır
   for (size_t i = 0; i < BOYUT; ++i) {
      printf("%3d", a[i]);
   }

   // a[3]'ün değerini yazdır
   printf("\n\n\nDizi elemanını değer olarak geçmenin etkileri:\n\n"
      "a[3]'ün değeri %d\n", a[3]);

   elemanDegistir(a[3]); // dizi elemanı a[3]'ü değer olarak geç

   // a[3]'ün değerini yazdır
   printf("a[3]'ün değeri %d\n", a[3]);
}

// diziDegistir fonksiyonunda, "b" orijinal dizi "a"yı bellekte işaret eder
void diziDegistir(int b[], size_t boyut) {
   // her dizi elemanını 2 ile çarp
   for (size_t j = 0; j < boyut; ++j) {
      b[j] *= 2; // aslında orijinal diziyi değiştirir
   }
}

// elemanDegistir fonksiyonunda, "e" main'den geçilen dizi elemanı a[3]'ün yerel bir kopyasıdır
void elemanDegistir(int e) {
   e *= 2; // parametreyi 2 ile çarp
   printf("elemanDegistir fonksiyonundaki değer %d\n", e);
}
