// fig06_15.c
// Sıralı bir dizinin ikili araması.
#include <stdio.h>
#define BOYUT 15

// fonksiyon prototipleri
int ikiliArama(const int b[], int anahtar, size_t dusuk, size_t yuksek);
void baslikYaz(void);
void satirYaz(const int b[], size_t dusuk, size_t orta, size_t yuksek);

// main fonksiyonu programın çalışmasını başlatır
int main(void) {
   int a[BOYUT] = {0}; // dizi a'yı oluştur

   // veri oluştur
   for (size_t i = 0; i < BOYUT; ++i) {
      a[i] = 2 * i;
   }

   printf("%s", "0 ile 28 arasında bir sayı girin: ");
   int anahtar = 0; // dizide bulunacak değer
   scanf("%d", &anahtar);

   baslikYaz();

   // dizideki anahtarı ara
   int sonuc = ikiliArama(a, anahtar, 0, BOYUT - 1);

   // sonuçları göster
   if (sonuc != -1) {
      printf("\n%d %d. indekste bulundu\n", anahtar, sonuc);
   }
   else {
      printf("\n%d bulunamadı\n", anahtar);
   }
}

// bir dizinin ikili aramasını gerçekleştiren fonksiyon
int ikiliArama(const int b[], int anahtar, size_t dusuk, size_t yuksek) {
   // düşük indeks yüksek indeksten büyük olana kadar döngü devam eder
   while (dusuk <= yuksek) {
      size_t orta = (dusuk + yuksek) / 2; // orta indeksi belirle

      // bu döngü iterasyonunda kullanılan alt diziyi göster
      satirYaz(b, dusuk, orta, yuksek);

      // anahtar eşleşirse, orta indeksi döndür
      if (anahtar == b[orta]) {
         return orta;
      }
      else if (anahtar < b[orta]) { // anahtar < b[orta] ise yüksek değeri ayarla
         yuksek = orta - 1; // bir sonraki iterasyon dizinin sol kısmını arar
      }
      else { // anahtar > b[orta] ise düşük değeri ayarla
         dusuk = orta + 1; // bir sonraki iterasyon dizinin sağ kısmını arar
      }
   } // döngü sonu

   return -1; // anahtar bulunamadı
}

// Çıktı için bir başlık yazdır
void baslikYaz(void) {
   puts("\nİndeksler:");

   // sütun başlığını yazdır
   for (int i = 0; i < BOYUT; ++i) {
      printf("%3d ", i);
   }

   puts(""); // yeni bir satır başlat

   // - karakterlerinden oluşan bir çizgi yazdır
   for (int i = 1; i <= 4 * BOYUT; ++i) {
      printf("%s", "-");
   }

   puts(""); // yeni bir satır başlat
}

// Çalıştırılan alt diziyi gösteren bir satır yazdır
void satirYaz(const int b[], size_t dusuk, size_t orta, size_t yuksek) {
   // tüm diziyi döngü ile tara
   for (size_t i = 0; i < BOYUT; ++i) {
      // şu anki alt dizi aralığının dışında ise boşluk göster
      if (i < dusuk || i > yuksek) {
         printf("%s", "    ");
      }
      else if (i == orta) { // orta elemanı göster
         printf("%3d*", b[i]); // orta değeri işaretle
      }
      else { // alt dizideki diğer elemanları göster
         printf("%3d ", b[i]);
      }
   }

   puts(""); // yeni bir satır başlat
}
