// fig06_02.c
// Bir dizinin elemanlarını bir başlatıcı liste ile başlatma.
#include <stdio.h>

// main fonksiyonu programın çalışmasını başlatır
int main(void) {
   int dizi[5] = {32, 27, 64, 18, 95}; // dizi, bir başlatıcı liste ile başlatılıyor

   printf("%s%8s\n", "Eleman", "Değer");

   // dizinin içeriğini tablo formatında yazdır
   for (size_t indeks = 0; indeks < 5; ++indeks) {
      printf("%7zu%8d\n", indeks, dizi[indeks]);
   }
}
