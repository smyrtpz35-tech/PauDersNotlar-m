// fig06_14.c
// Bir dizinin doğrusal araması.
#include <stdio.h>
#define BOYUT 100

// fonksiyon prototipi
int dogrusalArama(const int dizi[], int anahtar, size_t boyut);

// main fonksiyonu programın çalışmasını başlatır
int main(void) {
   int a[BOYUT] = {0}; // dizi a'yı oluştur

   // bazı veriler oluştur
   for (size_t x = 0; x < BOYUT; ++x) {
      a[x] = 2 * x;
   }

   printf("Arama anahtarını girin: ");
   int aramaAnahtari = 0; // dizide bulunacak değer
   scanf("%d", &aramaAnahtari);

   // aramaAnahtarını dizi a'da bulmaya çalış
   int altIndeks = dogrusalArama(a, aramaAnahtari, BOYUT);

   // sonuçları göster
   if (altIndeks != -1) {
      printf("Değer %d. indeksde bulundu\n", altIndeks);
   }
   else {
      puts("Değer bulunamadı");
   }
}

// anahtarı her dizi elemanı ile karşılaştır, anahtar bulunduğunda
// veya dizinin sonuna gelindiğinde, anahtar bulunursa dizinin indeksini
// geri döndür, bulunmazsa -1 döndür
int dogrusalArama(const int dizi[], int anahtar, size_t boyut) {
   // diziyi döngü ile tara
   for (size_t n = 0; n < boyut; ++n) {
      if (dizi[n] == anahtar) {
         return n; // anahtarın bulunduğu konumu döndür
      }
   }

   return -1; // anahtar bulunamadı
}
