// fig06_06.c
// Çubuk grafik gösterme.
#include <stdio.h>
#define BOYUT 5

// main fonksiyonu programın çalışmasını başlatır
int main(void) {
   // bir başlatıcı liste kullanarak dizi n'yi başlat
   int dizi[BOYUT] = {19, 3, 15, 7, 11};

   printf("%s%13s%17s\n", "Eleman", "Değer", "Çubuk Grafik");

   // dizi n'nin her elemanı için çubuk grafik bir çubuk yazdır
   for (size_t i = 0; i < BOYUT; ++i) {
      printf("%6zu%12d%4s", i, dizi[i], "");

      for (int j = 1; j <= dizi[i]; ++j) { // bir çubuk yazdır
         printf("%c", '*');
      }

      puts(""); // bir çubuğu yeni satır ile bitir
   }
}
