// fig06_07.c
// Altı yüzlü bir zar 60.000.000 kez atılıyor
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#define BOYUT 7

// main fonksiyonu programın çalışmasını başlatır
int main(void) {
   srand(time(NULL)); // rastgele sayı üreteciyi başlat

   int frekans[BOYUT] = {0}; // tüm frekans sayaçlarını 0 ile başlat

   // zarı 60.000.000 kez at
   for (int atis = 1; atis <= 60000000; ++atis) {
      size_t yuz = 1 + rand() % 6;
      ++frekans[yuz]; // Fig. 5.5'teki tüm switch yapısının yerine geçiyor
   }

   printf("%s%17s\n", "Yüz", "Frekans");

   // frekans elemanlarını 1-6 arası tablo formatında yazdır
   for (size_t yuz = 1; yuz < BOYUT; ++yuz) {
      printf("%3zu%17d\n", yuz, frekans[yuz]);
   }
}
