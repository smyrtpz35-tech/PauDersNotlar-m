// fig06_01.c
// Bir dizinin elemanlarını sıfır olarak başlatma.
#include <stdio.h>

// main fonksiyonu programın çalışmasını başlatır
int main(void) {
   int dizi[5]; // dizi, beş tamsayıdan oluşan bir dizidir

   // dizi elemanlarını 0 yap
   for (size_t indeks = 0; indeks < 5; ++indeks) {
      dizi[indeks] = 0; // indeks konumundaki elemanı 0 yap
   }

   printf("%s%8s\n", "Eleman", "Değer");

   // dizinin içeriğini tablo formatında yazdır
   for (size_t indeks = 0; indeks < 5; ++indeks) {
      printf("%7zu%8d\n", indeks, dizi[indeks]);
   }
}
