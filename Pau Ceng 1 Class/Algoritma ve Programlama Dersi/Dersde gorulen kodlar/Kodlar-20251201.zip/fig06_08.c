// fig06_08.c
// Karakter dizilerini (string) ele alma.
#include <stdio.h>
#define BOYUT 20

// main fonksiyonu programın çalışmasını başlatır
int main(void) {
   char dizi1[BOYUT] = ""; // 20 karakterlik yer ayırır
   char dizi2[] = "string literal"; // 15 karakterlik yer ayırır

   // kullanıcıdan bir string iste ve bunu dizi1'e oku
   printf("%s", "Bir string girin (en fazla 19 karakter): ");
   scanf("%19s", dizi1); // en fazla 19 karakter oku

   // stringleri yazdır
   printf("dizi1: %s\n, dizi2: %s\n", dizi1, dizi2);
   puts("Dizi1'in karakterleri arasında boşluk bırakarak yazdırılıyor:");

   // null karakterine ulaşılana kadar karakterleri yazdır
   for (size_t i = 0; i < BOYUT && dizi1[i] != '\0'; ++i) {
      printf("%c ", dizi1[i]);
   }

   puts("");
}
