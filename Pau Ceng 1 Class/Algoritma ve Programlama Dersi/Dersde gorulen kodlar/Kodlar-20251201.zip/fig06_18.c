// fig06_18.c
// C99'da değişken uzunluklu dizilerin kullanımı
#include <stdio.h>

// fonksiyon prototipleri
void yazdir1DBellek(size_t boyut, int dizi[boyut]);
void yazdir2DBellek(size_t satir, size_t sutun, int dizi[satir][sutun]);

int main(void) {
   printf("%s", "Tek boyutlu bir dizinin boyutunu girin: ");
   int diziBoyut = 0; // 1-D dizisinin boyutu
   scanf("%d", &diziBoyut);

   int dizi[diziBoyut]; // 1-D değişken uzunluklu dizi tanımlama

   printf("%s", "2-D bir dizideki satır ve sütun sayısını girin: ");
   int satir1 = 0; // 2-D dizideki satır sayısı
   int sutun1 = 0; // 2-D dizideki sütun sayısı
   scanf("%d %d", &satir1, &sutun1);

   int dizi2D1[satir1][sutun1]; // 2-D değişken uzunluklu dizi tanımlama

   printf("%s", "Başka bir 2-D dizideki satır ve sütun sayısını girin: ");
   int satir2 = 0; // 2-D dizideki satır sayısı
   int sutun2 = 0; // 2-D dizideki sütun sayısı
   scanf("%d %d", &satir2, &sutun2);

   int dizi2D2[satir2][sutun2]; // 2-D değişken uzunluklu dizi tanımlama

   // VLA üzerinde sizeof operatörünü test etme
   printf("\nsizeof(dizi) %zu baytlık dizi boyutu verir\n",
      sizeof(dizi));

   // 1-D VLA elemanlarına değer atama
   for (size_t i = 0; i < diziBoyut; ++i) {
      dizi[i] = i * i;
   }

   // İlk 2-D VLA elemanlarına değer atama
   for (size_t i = 0; i < satir1; ++i) {
      for (size_t j = 0; j < sutun1; ++j) {
         dizi2D1[i][j] = i + j;
      }
   }

   // İkinci 2-D VLA elemanlarına değer atama
   for (size_t i = 0; i < satir2; ++i) {
      for (size_t j = 0; j < sutun2; ++j) {
         dizi2D2[i][j] = i + j;
      }
   }

   puts("\nTek boyutlu dizi:");
   yazdir1DBellek(diziBoyut, dizi); // 1-D VLA'yi fonksiyona gönderme

   puts("\nİlk iki boyutlu dizi:");
   yazdir2DBellek(satir1, sutun1, dizi2D1); // 2-D VLA'yi fonksiyona gönderme

   puts("\nİkinci iki boyutlu dizi:");
   yazdir2DBellek(satir2, sutun2, dizi2D2); // diğer 2-D VLA'yi fonksiyona gönderme
}

void yazdir1DBellek(size_t boyut, int dizi[boyut]) {
   // dizinin içeriğini yazdır
   for (size_t i = 0; i < boyut; i++) {
      printf("dizi[%zu] = %d\n", i, dizi[i]);
   }
}

void yazdir2DBellek(size_t satir, size_t sutun, int dizi[satir][sutun]) {
   // dizinin içeriğini yazdır
   for (size_t i = 0; i < satir; ++i) {
      for (size_t j = 0; j < sutun; ++j) {
         printf("%5d", dizi[i][j]);
      }

      puts("");
   }
}
