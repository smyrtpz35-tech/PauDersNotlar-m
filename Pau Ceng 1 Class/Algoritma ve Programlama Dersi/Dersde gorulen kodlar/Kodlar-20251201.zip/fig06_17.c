// fig06_17.c
// İki boyutlu dizi manipülasyonları.
#include <stdio.h>
#define OGRENCILER 3
#define SINAVLAR 4

// fonksiyon prototipleri
int minimum(const int notlar[][SINAVLAR], size_t ogrenciler, size_t sinavlar);
int maksimum(const int notlar[][SINAVLAR], size_t ogrenciler, size_t sinavlar);
double ortalama(const int notlar[], size_t sinavlar);
void diziyiYazdir(const int notlar[][SINAVLAR], size_t ogrenciler, size_t sinavlar);

// main fonksiyonu programın çalışmasını başlatır
int main(void) {
   // üç öğrenci için sınav notları (satırlar)
   int ogrenciNotlari[OGRENCILER][SINAVLAR] =
      {{77, 68, 86, 73},
       {96, 87, 89, 78},
       {70, 90, 86, 81}};

   // ogrenciNotlari dizisini yazdır
   puts("Dizi şu şekildedir:");
   diziyiYazdir(ogrenciNotlari, OGRENCILER, SINAVLAR);

   // en düşük ve en yüksek not değerlerini belirle
   printf("\n\nEn düşük not: %d\nEn yüksek not: %d\n",
      minimum(ogrenciNotlari, OGRENCILER, SINAVLAR),
      maksimum(ogrenciNotlari, OGRENCILER, SINAVLAR));

   // her öğrenci için ortalama notu hesapla
   for (size_t ogrenci = 0; ogrenci < OGRENCILER; ++ogrenci) {
      printf("Öğrenci %zu'nun ortalama notu %.2f\n",
         ogrenci, ortalama(ogrenciNotlari[ogrenci], SINAVLAR));
   }
}

// En düşük notu bulma
int minimum(const int notlar[][SINAVLAR], size_t ogrenciler, size_t sinavlar) {
   int dusukNot = 100; // en yüksek olası not ile başlat

   // notların satırlarında döngü
   for (size_t satir = 0; satir < ogrenciler; ++satir) {
      // notların sütunlarında döngü
      for (size_t sutun = 0; sutun < sinavlar; ++sutun) {
         if (notlar[satir][sutun] < dusukNot) {
            dusukNot = notlar[satir][sutun];
         }
      }
   }

   return dusukNot; // en düşük notu döndür
}

// En yüksek notu bulma
int maksimum(const int notlar[][SINAVLAR], size_t ogrenciler, size_t sinavlar) {
   int yuksekNot = 0; // en düşük olası not ile başlat

   // notların satırlarında döngü
   for (size_t satir = 0; satir < ogrenciler; ++satir) {
      // notların sütunlarında döngü
      for (size_t sutun = 0; sutun < sinavlar; ++sutun) {
         if (notlar[satir][sutun] > yuksekNot) {
            yuksekNot = notlar[satir][sutun];
         }
      }
   }

   return yuksekNot; // en yüksek notu döndür
}

// Belirli bir öğrenci için ortalama notu belirleme
double ortalama(const int notlar[], size_t sinavlar) {
   int toplam = 0; // sınav notlarının toplamı

   // bir öğrenci için tüm sınavları toplam
   for (size_t sinav = 0; sinav < sinavlar; ++sinav) {
      toplam += notlar[sinav];
   }

   return (double) toplam / sinavlar; // ortalama
}

// Diziyi yazdırma
void diziyiYazdir(const int notlar[][SINAVLAR], size_t ogrenciler, size_t sinavlar) {
   // sütun başlıklarını yazdır
   printf("%s", "                 [0]  [1]  [2]  [3]");

   // notları tablo formatında yazdır
   for (size_t satir = 0; satir < ogrenciler; ++satir) {
      // satır için etiket yazdır
      printf("\nöğrenciNotları[%zu] ", satir);

      // bir öğrenci için notları yazdır
      for (size_t sutun = 0; sutun < sinavlar; ++sutun) {
         printf("%-5d", notlar[satir][sutun]);
      }
   }
}
