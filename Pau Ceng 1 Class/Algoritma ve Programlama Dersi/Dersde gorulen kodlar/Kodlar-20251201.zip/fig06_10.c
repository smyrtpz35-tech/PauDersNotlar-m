// fig06_10.c
// Dizi adı, dizinin ilk elemanının adresiyle aynıdır.
#include <stdio.h>

// main fonksiyonu programın çalışmasını başlatır
int main(void) {
   char dizi[5] = ""; // boyutu 5 olan bir dizi tanımla

   printf("    dizi = %p\n&dizi[0] = %p\n   &dizi = %p\n",
      dizi, &dizi[0], &dizi);
}
