
public class DataStructersHomework2026_1 {
	
	/*Sıralı olmayan iki adet yığıtı(stack), 3. bir yığıtta sıralı olarak birleştiren metodu yazınız. Metodunuz
Stack sınıfı haricinde bir sınıf içerisinde olacaktır.
Adım :
önce stackleri sıralamam gerek
en sonda da ikisini karşılaştırıp başka s3 staka a atmam gerek 	

			
			stackleri büyükten küçüğe karşılaştır 
*/
	
	//en son elemanı karşılaştırmak için 
	public static int peek(Stack s) throws Exception {
	    int val = s.pop();
	    s.push(val);
	    return val;
	}
	//Stackleri büyükten küçüğe sırala
	public static Stack StackSıralıSıralama(Stack s1) throws Exception{
		Stack temps1= new Stack(s1.size());
		while(!s1.isEmpty()) {	
			int val= findMax(s1);
			temps1.push(val);
		}
		return temps1;
	}
	//en büyük bul
	//en büyük elemanı bul ki yedek stacke at
	 public static int findMax(Stack s)throws Exception{
	        if(s.isEmpty()){
	            throw new Exception("Stack bos.");
	        }
	        
	        Stack temp = new Stack(s.size());
	        int max = s.pop();
	        temp.push(max);        
	        while(!s.isEmpty()){
	            int value = s.pop();
	            if(max < value){
	                max = value;
	            }
	            temp.push(value);
	        }        
	        while(!temp.isEmpty()){
	            s.push(temp.pop());
	        }      
	        remove(s,max);
	        return max;
	    }
	 
	 //bulduğun en büyük elemanı aynı vermemesi için stackden çıkar 
	 public static void remove(Stack s, int sayi)throws Exception{
	        Stack temp = new Stack(s.size());

	        while(!s.isEmpty()){
	            int value = s.pop();
	            
	            if(value == sayi){
	                break;
	            }
	            temp.push(value);
	        }
	        
	        while(!temp.isEmpty()){
	            s.push(temp.pop());
	        } 
	    }
	 		
	 
	 //s3 e sıralama 
	public static Stack SıralıSıralama(Stack s1, Stack s2,Stack s3) throws Exception{
	
		Stack temps3= new Stack(s1.size()+s2.size());
	
		Stack a = StackSıralıSıralama(s1);
	    Stack b = StackSıralıSıralama(s2);
	    
	    while (!a.isEmpty() && !b.isEmpty()) {
	        if (peek(a) <= peek(b)) {
	            temps3.push(a.pop());
	        } else {
	            temps3.push(b.pop());
	        }
	    }
		
	    while (!a.isEmpty()) {
	        temps3.push(a.pop());
	    }
	    while (!b.isEmpty()) {
	        temps3.push(b.pop());
	    }

	    
	    while (!temps3.isEmpty()) {
	        s3.push(temps3.pop());
	    }

		
			return s3;
	}
	 public static void main(String[] args) throws Exception {
		 Stack s1 = new Stack(5);
		 Stack s2= new Stack(7);
		 Stack s3= new Stack(s1.size()+s2.size());
		 
		 s1.push(9);
		 s1.push(7);
		 s1.push(10);
		 s1.push(23);
		 s1.push(12);
		 s2.push(5);
		 s2.push(1);
		 s2.push(6);
		 s2.push(3);
		 s2.push(8);
		 s2.push(16);
		 s2.push(17);
		 s1.display();
		 s2.display();
		 
		 
		 s3=SıralıSıralama(s1,s2,s3);
	 
		 s3.display();
	 }
}
